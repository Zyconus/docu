package com.example.plant
import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class logout : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.logout)
        val button1 = findViewById<Button>(R.id.cancel)
        val button2 = findViewById<Button>(R.id.logout)
        button1.setOnClickListener {
            // Handle button 1 click
            val intent = Intent(this, scan::class.java)
            startActivity(intent)

            button2.setOnClickListener {
                // Handle button 2 click
                val intent = Intent(this, login::class.java)
                startActivity(intent)
            }
        }
    }

}