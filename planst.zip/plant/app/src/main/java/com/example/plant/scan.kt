package com.example.plant

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class scan : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.scan)
        val button1 = findViewById<Button>(R.id.log)
        val button2 = findViewById<Button>(R.id.scaner)
        button1.setOnClickListener {
            // Handle button 1 click
            val intent = Intent(this, logout::class.java)
            startActivity(intent)

            button2.setOnClickListener {
                // Handle button 2 click
                val intent = Intent(this, output::class.java)
                startActivity(intent)
            }
        }
    }

    }