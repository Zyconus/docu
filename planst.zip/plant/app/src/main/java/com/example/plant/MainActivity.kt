

package com.example.plant

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        enableEdgeToEdge()
        // Find the button by its ID
        val buttonNavigateToSecondActivity = findViewById<Button>(R.id.button1)

        // Set an OnClickListener for the button
        buttonNavigateToSecondActivity.setOnClickListener {
            // Create an Intent to navigate to SecondActivity
            val intent = Intent(this, login::class.java)
            startActivity(intent)
        }

    }
}

