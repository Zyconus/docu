package com.example.plant

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class login : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.login)
        // Find the button by its ID
        val buttonNavigateToSecondActivity = findViewById<Button>(R.id.buttonLogin)

        // Set an OnClickListener for the button
        buttonNavigateToSecondActivity.setOnClickListener {
            // Create an Intent to navigate to SecondActivity
            val intent = Intent(this, scan::class.java)
            startActivity(intent)
        }

    }

}